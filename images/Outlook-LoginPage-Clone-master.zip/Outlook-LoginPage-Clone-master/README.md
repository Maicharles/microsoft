Outlook Login Page Clone

A clone of the (now old) Microsoft Outlook Login page.